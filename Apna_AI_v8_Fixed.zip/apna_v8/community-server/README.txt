Apna AI Community Learning Server (Node.js 18+; no npm packages needed)

1. Set a strong admin token in your hosting environment:
   ADMIN_TOKEN=your-long-random-secret
2. Run: npm start
3. Host behind HTTPS before connecting the mobile/web app.
4. In Apna AI > Settings > Prefs, set Community learning server URL to the public HTTPS base URL.
5. Contributions from the app are queued at POST /community/contribute.
6. Admin review:
   GET /admin/pending with header Authorization: Bearer <ADMIN_TOKEN>
   POST /admin/approve with same header and JSON {"id":"..."}
   POST /admin/reject with same header and JSON {"id":"..."}
7. Approved knowledge is exposed to users through GET /community/export and GET /community/search?q=...

Important: Use HTTPS, a strong admin token, backups, moderation and privacy review. The app asks for explicit consent before each community upload. The backend rejects some common API-key/private-key patterns but this is not a complete privacy filter. Never contribute secrets or personal information.
