// Minimal community-learning server for Apna AI. Node.js 18+, no dependencies.
// Contributions are NEVER published automatically: an admin must approve them.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const PORT = Number(process.env.PORT || 8787);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const DB = path.join(__dirname, 'community-data.json');
function readDB(){let d;try{d=JSON.parse(fs.readFileSync(DB,'utf8'))}catch(e){if(e.code!=='ENOENT'){try{fs.copyFileSync(DB,DB+'.corrupt-'+Date.now())}catch{}}d={}}return {pending:Array.isArray(d.pending)?d.pending:[],approved:Array.isArray(d.approved)?d.approved:[]}}
function writeDB(db){fs.writeFileSync(DB+'.tmp',JSON.stringify(db,null,2));fs.renameSync(DB+'.tmp',DB)}
function send(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Cache-Control':'no-store'});res.end(JSON.stringify(data))}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>25000){reject(new Error('Payload too large'));req.destroy()}});req.on('end',()=>{try{resolve(JSON.parse(s||'{}'))}catch{reject(new Error('Invalid JSON'))}});req.on('error',reject)})}
function hasSensitiveText(s){return /(sk-[A-Za-z0-9_-]{12,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bpassword\s*[:=]|\bapi[_ -]?key\s*[:=])/i.test(s)}
function admin(req){if(!ADMIN_TOKEN)return false;const a=Buffer.from(String(req.headers.authorization||'')),b=Buffer.from('Bearer '+ADMIN_TOKEN);return a.length===b.length&&crypto.timingSafeEqual(a,b)}
// Very small per-IP rate limit for contributions (20/hour) and a cap on the review queue, so the queue cannot be spammed.
const hits=new Map();const MAX_PENDING=500;
function limited(ip){const now=Date.now(),h=(hits.get(ip)||[]).filter(t=>now-t<3600000);h.push(now);hits.set(ip,h);if(hits.size>5000)hits.clear();return h.length>20}
const server=http.createServer(async(req,res)=>{
  if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET, POST, OPTIONS'});return res.end()}
  const u=new URL(req.url,'http://localhost');
  if(req.method==='GET'&&u.pathname==='/health')return send(res,200,{ok:true,service:'Apna AI community learning',note:'Community contributions require manual approval.'});
  if(req.method==='GET'&&u.pathname==='/community/export'){const db=readDB();return send(res,200,{items:db.approved.map(({id,question,answer,created})=>({id,question,answer,created}))})}
  if(req.method==='GET'&&u.pathname==='/community/search'){const q=(u.searchParams.get('q')||'').toLowerCase().slice(0,300);const terms=q.split(/[^\p{L}\p{N}]+/u).filter(x=>x.length>2);const db=readDB();const items=db.approved.map(x=>({...x,score:terms.reduce((n,t)=>n+((x.question+' '+x.answer).toLowerCase().includes(t)?1:0),0)})).filter(x=>!terms.length||x.score>0).sort((a,b)=>b.score-a.score).slice(0,5).map(({id,question,answer,created})=>({id,question,answer,created}));return send(res,200,{items})}
  if(req.method==='POST'&&u.pathname==='/community/contribute'){try{const d=await body(req);const question=String(d.question||'').trim().slice(0,1500),answer=String(d.answer||'').trim().slice(0,3500);if(question.length<3||answer.length<3)return send(res,400,{error:'Question and answer are required.'});if(hasSensitiveText(question+'\n'+answer))return send(res,400,{error:'Possible secret/API key detected. Remove sensitive details before sharing.'});if(limited(req.socket.remoteAddress||'?'))return send(res,429,{error:'Too many contributions. Try again later.'});const db=readDB();if(db.pending.length>=MAX_PENDING)return send(res,503,{error:'Review queue is full. Try again later.'});const item={id:crypto.randomUUID(),question,answer,created:Date.now(),status:'pending'};db.pending.push(item);writeDB(db);return send(res,201,{ok:true,status:'pending_review',id:item.id})}catch(e){return send(res,400,{error:e.message})}}
  if(u.pathname.startsWith('/admin/')&&!admin(req))return send(res,401,{error:'Set ADMIN_TOKEN and send Authorization: Bearer <token>.'});
  if(req.method==='GET'&&u.pathname==='/admin/pending'){const db=readDB();return send(res,200,{items:db.pending})}
  if(req.method==='POST'&&u.pathname==='/admin/approve'){try{const d=await body(req);const db=readDB();const i=db.pending.findIndex(x=>x.id===d.id);if(i<0)return send(res,404,{error:'Pending item not found.'});const item=db.pending.splice(i,1)[0];delete item.status;db.approved.push(item);writeDB(db);return send(res,200,{ok:true,approved:item.id})}catch(e){return send(res,400,{error:e.message})}}
  if(req.method==='POST'&&u.pathname==='/admin/reject'){try{const d=await body(req);const db=readDB();const before=db.pending.length;db.pending=db.pending.filter(x=>x.id!==d.id);writeDB(db);return send(res,200,{ok:true,rejected:before!==db.pending.length})}catch(e){return send(res,400,{error:e.message})}}
  return send(res,404,{error:'Not found'})
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Apna AI community server listening on ${PORT}. Set ADMIN_TOKEN before public hosting.`));
